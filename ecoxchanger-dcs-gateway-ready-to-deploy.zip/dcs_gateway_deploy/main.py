import os
from datetime import datetime, timezone
from typing import Any

import httpx
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="EcoXChanger DCS Gateway", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["GET"],
    allow_headers=["*"],
)

FINGRID_API_KEY = os.getenv("FINGRID_API_KEY", "").strip()
DATASET_ID = int(os.getenv("FINGRID_DATASET_ID", "201"))
FINGRID_LATEST_URL = f"https://data.fingrid.fi/api/datasets/{DATASET_ID}/data/latest"

# Last public sample used only as a transparent fallback when no API key is configured.
FALLBACK = {
    "datasetId": 201,
    "startTime": "2026-10-30T14:00:00.000Z",
    "endTime": "2026-10-30T14:03:00.000Z",
    "value": 722.826,
}


def normalize_measurement(raw: dict[str, Any], live: bool) -> dict[str, Any]:
    measured_at = raw.get("endTime") or raw.get("startTime")
    return {
        "source": "Fingrid",
        "dataset_id": raw.get("datasetId", DATASET_ID),
        "measurement": "cogeneration_district_heating_power",
        "value": raw.get("value"),
        "unit": "MW",
        "start_time_utc": raw.get("startTime"),
        "end_time_utc": raw.get("endTime"),
        "measured_at_utc": measured_at,
        "quality": "actual_operational_measurement" if live else "historical_fallback",
        "live": live,
    }


@app.get("/")
def root() -> dict[str, Any]:
    return {
        "service": "EcoXChanger DCS Gateway",
        "status": "ok",
        "endpoints": {
            "latest": "/latest",
            "health": "/health",
            "docs": "/docs",
        },
    }


@app.get("/health")
def health() -> dict[str, Any]:
    return {
        "status": "ok",
        "time_utc": datetime.now(timezone.utc).isoformat(),
        "provider": "Fingrid",
        "dataset_id": DATASET_ID,
        "api_key_configured": bool(FINGRID_API_KEY),
    }


@app.get("/latest")
async def latest() -> dict[str, Any]:
    now = datetime.now(timezone.utc).isoformat()

    if not FINGRID_API_KEY:
        return {
            "status": "degraded",
            "server_time_utc": now,
            "data": normalize_measurement(FALLBACK, live=False),
            "warning": "FINGRID_API_KEY is not configured. This is the last public fallback sample, not live data.",
            "source_url": "https://data.fingrid.fi/en/datasets/201",
        }

    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            response = await client.get(
                FINGRID_LATEST_URL,
                headers={"x-api-key": FINGRID_API_KEY, "accept": "application/json"},
            )
        if response.status_code != 200:
            raise HTTPException(
                status_code=502,
                detail=f"Fingrid returned HTTP {response.status_code}",
            )
        raw = response.json()
        return {
            "status": "success",
            "server_time_utc": now,
            "data": normalize_measurement(raw, live=True),
            "source_url": "https://data.fingrid.fi/en/datasets/201",
            "refresh": "on_request",
            "update_interval": "3 minutes",
            "note": "This is cogeneration/district-heating power. It is not a direct measurement of unused exhaust waste heat.",
        }
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Upstream error: {type(exc).__name__}")
