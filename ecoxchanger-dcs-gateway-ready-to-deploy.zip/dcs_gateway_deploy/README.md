# EcoXChanger DCS Gateway — ready to deploy

This is a real HTTPS-ready REST API service for Render or any Python/FastAPI host.

## Endpoints

- `GET /` — service info
- `GET /health` — health check
- `GET /latest` — latest Fingrid measurement
- `GET /docs` — Swagger/OpenAPI UI

## Live data

Set `FINGRID_API_KEY` in the hosting provider's environment variables. Fingrid requires the API key in the `x-api-key` HTTP header. Dataset `201` is updated every 3 minutes.

Without the API key, `/latest` returns a clearly marked historical fallback sample and does **not** claim to be live.

## Render

1. Push this folder to a GitHub repository.
2. In Render: New → Web Service.
3. Connect the repository.
4. Render will use `render.yaml`, or use:
   - Build: `pip install -r requirements.txt`
   - Start: `uvicorn main:app --host 0.0.0.0 --port $PORT`
5. Add environment variable `FINGRID_API_KEY`.
6. Deploy.

Render assigns a public `https://<service-name>.onrender.com` URL.

## Important data meaning

Fingrid dataset 201 is real-time cogeneration/district-heating power. It is related to useful heat generation in CHP systems, but it is **not** a plant-level direct sensor reading of unused waste-heat temperature, mass flow, or recoverable heat.
